
package miprimeragente;

import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;


public class AgEnviaMensaje extends Agent{

class comportEnvia extends SimpleBehaviour{
    
String nameAgent;

public comportEnvia (String n) {nameAgent = n;}
public void action(){
    
    doWait(20000);
    ACLMessage acl = new ACLMessage(ACLMessage.REQUEST);
    AID Agrec = new AID(nameAgent,AID.ISLOCALNAME);
    acl.addReceiver(Agrec);
    acl.setContent("Mensaje1");
    send(acl);
}

public boolean done(){
    return true;
}
}

protected void setup(){
    
    Object[] listaparametros = getArguments();
    String nameAgenteR = (String) listaparametros[0];
    
    System.out.println("Hola Mundo Soy El Primer Agente " + getLocalName());
    comportEnvia ce = new comportEnvia(nameAgenteR);
    addBehaviour(ce);
    
}
}
