package miprimeragente;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

public class Agcomportamientosimple extends Agent {

    class TareaSimple extends SimpleBehaviour {

        public void action() {
            for (int i = 0; i < 10; i++) {
                System.out.println("Ciclo " + i);
            }
        }

        public boolean done() {
            return true;
        }
    }

    protected void setup() {
        System.out.println("Primer agente con comportamiento JADE");
        TareaSimple cl = new TareaSimple();
        addBehaviour(cl);
    }
}
