/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miprimeragente;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;



/**
 *
 * @author utp
 */
public class AgComportamientoSimple extends Agent {
    
    class TareaSimple extends SimpleBehaviour {
        public void action(){
            for (int i=0;i<10;i++)
            System.out.println("Ciclo "+i);
        }
        
        public boolean done(){
            return true;
            
        }
    }
    protected void setup(){
        System.out.println("Primer agente con agente con Comportamiento JADE");
        TareaSimple cl = new TareaSimple();
        addBehaviour(cl);
    }
  
    
}
