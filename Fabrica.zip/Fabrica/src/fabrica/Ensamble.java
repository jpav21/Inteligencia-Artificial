import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.*;


public class Ensamble extends Agent {
    private static final String ONE_STATE = "Inicio";
    private static final String TWO_STATE = "Marco";
    private static final String THREE_STATE = "Relacion";
    private static final String FOUR_STATE = "Llanta";
    private static final String FIVE_STATE = "Direccion";
    private static final String SIX_STATE = "Fin";    
    private final int CERO = 0;
    private final int UNO = 1;
    private final int DOS = 2;
    
    private String entrada = "";

    @Override
    public void setup () {
    entrada = "012012212";

}

    
    
    
        class Recibirsolicitud extends SimpleBehaviour {

        private boolean fin = false;

        public void action() {
            System.out.println(" Preparandose para recibir");

            //Obtiene el primer mensaje de la cola de mensajes
            ACLMessage mensaje = receive();

            if (mensaje != null) {
                System.out.println(getLocalName() + ": acaba de recibir el siguiente mensaje: ");
                System.out.println(mensaje.toString());
                //innsta
                bicicleta=new Partes();
                MiFSMBehaviour b = new MiFSMBehaviour(this.myAgent, entrada);
                    addBehaviour(b);
                //mandarla a ensam
                fin = true;
            }
        }

        public boolean done() {
            return fin;
        }
    }
    
        
    private class MiFSMBehaviour extends FSMBehaviour{
        private int transicion = 0;
        private String entrada = "";
            
        public MiFSMBehaviour (Agent _agente,String ent){
        super(_agente);
        entrada = ent;
        }
    
    
    @Override
    public void onStart() {
        registerFirstState(new EstadoInicio(), ONE_STATE);      //Establece cúal es el estado inicial
        registerState(new EstadoMarco(), TWO_STATE);           //Establece estados intermedios
        registerState(new EstadoRelacion(), THREE_STATE);         //.
        registerState(new EstadoLlanta(), FOUR_STATE);          //.
        registerState(new EstadoDireccion(), FIVE_STATE);          //.
        registerLastState(new EstadoFin(), SIX_STATE);       //Establece cúal es el estado final
        
        registerTransition (ONE_STATE, TWO_STATE, UNO);
        registerTransition (TWO_STATE, THREE_STATE, UNO);
        registerTransition (TWO_STATE, FOUR_STATE, CERO);
        registerTransition (TWO_STATE, FIVE_STATE, DOS);
        registerTransition (THREE_STATE, FOUR_STATE, CERO);
        registerTransition (THREE_STATE, FIVE_STATE, UNO);
        registerTransition (FOUR_STATE, THREE_STATE, UNO);
        registerTransition (FOUR_STATE, FIVE_STATE, CERO);
        registerTransition (FIVE_STATE, THREE_STATE, UNO);
        registerTransition (FIVE_STATE, FOUR_STATE, DOS);
        registerTransition (FIVE_STATE, SIX_STATE, CERO);
    }
    
    protected boolean checkTermination (boolean currentDone, int currentResult){
        System.out.println("Terminado" + currentName);
        return super.checkTermination (currentDone, currentResult);
    }
    public int getEntrada(){
        int tipoEvento = CERO;
        if (entrada.length()<1) return tipoEvento;
        else tipoEvento = Integer.parseInt (entrada.substring(0,1));
        entrada = entrada.substring(1, entrada.length());
        return tipoEvento;
    }
    
    private class EstadoInicio extends OneShotBehaviour {
        public void action(){System.out.println("Primer estado");}
        public int onEnd(){return getEntrada();}
    }
    private class EstadoMarco extends OneShotBehaviour {
        public void action(){System.out.println("Estado marco");}
        public int onEnd(){return getEntrada();}
    }
    private class EstadoRelacion extends OneShotBehaviour {
        public void action(){System.out.println("Estado  relacion");}
        public int onEnd(){return getEntrada();}
    }
    private class EstadoLlanta extends OneShotBehaviour {
        public void action(){System.out.println("Estado llanta");}
        public int onEnd(){return getEntrada();}
    }
    private class EstadoDireccion extends OneShotBehaviour {
        public void action(){System.out.println("Estado direccion");}
        public int onEnd(){return getEntrada();}
    }
    private class EstadoFin extends OneShotBehaviour {
        public void action(){System.out.println("Estado final");}
        public int onEnd(){return getEntrada();}
    }
    
    }
}