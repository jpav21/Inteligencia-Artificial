/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fabrica;



import jade.core.Agent;

/**
 *
 * @author DELL
 */
public class Partes extends Agent {
    
    int Marco = 0;
    int Relacion= 0;
    int Llanta = 0;
    int Direccion = 0;
    
    public int getMarco() {
        return Marco;
    }

    public void setMarco(int Marco) {
        this.Marco = Marco;
    }

    public int getRelacion() {
        return Relacion;
    }

    public void setRelacion(int Relacion) {
        this.Relacion = Relacion;
    }

    public int getLlanta() {
        return Llanta;
    }

    public void setLlanta(int Llanta) {
        this.Llanta = Llanta;
    }

    public int getDireccion() {
        return Direccion;
    }

    public void setDireccion(int Direccion) {
        this.Direccion = Direccion;
    }
    
    
  

    
    
}
