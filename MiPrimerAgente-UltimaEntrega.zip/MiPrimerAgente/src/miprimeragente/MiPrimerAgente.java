/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miprimeragente;
import jade.core.Agent;
    
/**
 *
 * @author Familia
 */
public class MiPrimerAgente extends Agent{

    @Override
    public void setup(){
        
        Object [] listaparametros = getArguments();
        String primerArgumento = (String) listaparametros[0];        
        System.out.println(("Hola Gente soy el agente ")+ getLocalName()+ " Argumento " + primerArgumento);
    }
    
}
