package miprimeragente;

import jade.core.Agent;

public class MiPrimerAgente extends Agent {

    public void setup() {
        Object[] listaparametros = getArguments();
        String primerArgumento = (String) listaparametros[0];
        System.out.println(("Hola Gente soy el agente ") + getLocalName() + " Argumento " + primerArgumento);
    }

}
