
package miprimeragente;

import jade.core.Agent;
import jade.domain.FIPAException;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAAgentManagement.DFAgentDescription;


public class AgRegistrarServicio extends Agent{
    
    public String Servicio;
    
    protected void setup(){
        Object [] arg2 = getArguments();
        Servicio = (String) arg2[0];
        
        System.out.println("El nombre de este agente es :" + this.getLocalName() +" Yo doy el servicio" + Servicio); 
        registrerService();
        
    }
    
    private void registrerService()
    {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(this.getAID());
        
        ServiceDescription sd = new ServiceDescription();
        sd.setType(Servicio);
        sd.setName(Servicio);
        
        dfd.addServices(sd);
        try{
            DFService.register(this,dfd);
        }
        catch(FIPAException ex)
        {
            System.err.println("El agente :" + getLocalName() + "No ha podido registrar el servicio : " + ex.getMessage());
            doDelete();
        }
    }
            
            
    
}
